<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


    <title>Document</title>
    
</head>
<body>

    <form action="http://localhost/L3IAGE/Epidemia/src/controller/PersonneController.php" method="post" style="
      background-color: #87CEFA; height: 128vh; width: 100%;" name="form" class="col-md-12 offset-md-12 center">
  <div class ="form-group">

        <h4 style="text-align: center; ">Ajouter une personne <br></h4>
        <div class=" form-group col-md-6">
            <label for="" class="control-label">Nom : </label>
            <input type="text" name="nomP"  />
           
        </div>
        <div class=" form-group col-md-6">
            <label for="" class="control-label">Prenom : </label>
            <input type="text" name="prenomP"  />
           
        </div>
        <div class=" form-group col-md-6">
            <label for="" class="control-label">Numero de telephone : </label>
            <input type="number" name="numTel"/>
        </div>
        <div class=" form-group col-md-6">
            <label for="" class="control-label">Adresse : </label>
            <input type="text" name="adresse" />
        </div>
        <div class=" form-group col-md-6">
            <label for="" class="control-label">Sexe : </label>
            <input type="text" name="sexe" />
        </div>
        <div class=" form-group col-md-6">
            <label for="" class="control-label">Résultat: </label>
            <select name="résultat"> 
                <option value="positive"> positive </option>
                <option value="négative"> négative</option>
                <option value="symptômatique">symptômatique</option>
            </select>
        </div>
       
        <div>
            <input class=" form-group col-md-6" type="submit" name="submit" value="Register"/>
            <input class=" form-group col-md-6" type="reset" name="reset" value="Cancel"/>
        </div>
        
    </form>

    </div>
    </div>
</body>
</html>