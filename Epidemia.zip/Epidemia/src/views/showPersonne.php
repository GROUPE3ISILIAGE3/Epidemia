<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

th {
  background-color: #4286f4;
  color: white;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

tr:hover {
  background-color: #ddd;
}

form {
  width: 100%;
  padding: 20px;
  text-align: center;
}

body {
  font-family: Arial, sans-serif;
  font-size: 16px;
}

    </style>
</head>
<form action="">
    <body>
        <table>
            <tr>
                <th>ID  :</th>
                <th>Nom  :</th>
                <th>Prenom :</th>
                <th>Numero telephone :</th>
                <th>Adresse :</th>
                <th>Sexe :</th>
                <th>Résultat :</th>
            
            </tr>
            <?php 
                include_once "../repository/Fonction.php";

                $edb = new Fonction();

                $Personne = $edb->GetAllPersonne();

                foreach ($Personne as $personne) 
                {
                    echo "<tr>
                            <td>$personne[0]</td>
                            <td>$personne[1]</td>
                            <td>$personne[2]</td>
                            <td>$personne[3]</td>
                            <td>$personne[4]</td>
                            <td>$personne[5]</td>
                            <td>$personne[6]</td>
                            
                        </tr>";
                }
            ?>
        </table>
        </form>
    </body>
</html>