<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>Nom Pays :</th>
            <th>population :</th>
            <th>liste population :</th>
         
        </tr>
        <?php 
            include_once "../repository/Fonction.php";

            $edb = new Fonction();

            $Pays = $edb->getAllPays();

            foreach ($Pays as $pays) 
            {
                echo "<tr>
                        <td>$pays[1]</td>
                        <td>$pays[2]</td>
                        <td>$pays[3]</td>
                        
                    </tr>";
            }
        ?>
    </table>
</body>
</html>